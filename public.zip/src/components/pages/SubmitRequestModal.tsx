import React, { useState } from "react";
import {
  Modal,
  Box,
  Typography,
  Radio,
  RadioGroup,
  FormControlLabel,
  Button,
  styled,
  IconButton,
  Tabs,
  Tab,
} from "@mui/material";
import SelectedPointDetail from "./SelectedPointDetail";
import CloseIcon from "@mui/icons-material/Close";
import "react-quill/dist/quill.snow.css";
import ReactQuill from "react-quill";

const ModalBox = styled(Box)({
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "90vw",
  backgroundColor: "white",
  paddingTop:'80px',
  maxHeight: "90vh",
  overflowY: "auto",
  display: "flex",
  flexDirection: "column",
});

const ContentWrapper = styled(Box)({
  display: "flex",
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "flex-start",
});

const LeftSection = styled(Box)({
  width: "65%",
  display: "flex",
  flexDirection: "column",
});

const RightSection = styled(Box)({
  width: "30%",
  padding: "10px",
  backgroundColor: "#f5f5f5",
  borderRadius: "5px",
});

const ButtonSection = styled(Box)({
  display: "flex",
  justifyContent: "flex-end",
  marginTop: "50px",
});

const StyledTabs = styled(Tabs)({
  backgroundColor: "var(--darkgray)",
  minHeight: "40px",
  marginBottom: "10px",
  ".MuiTabs-indicator": {
    display: "none",
  },
});

const StyledTab = styled(Tab)({
  color: "white",
  fontWeight: "bold",
  minHeight: "40px",
  textTransform: "none",
  width: "50%",
  "&.Mui-selected": {
    backgroundColor: "var(--gray)",
    color: "white",
  },
});

const TabPanel: React.FC<{
  value: number;
  index: number;
  children: React.ReactNode;
}> = ({ value, index, children }) => {
  return (
    <div role="tabpanel" hidden={value !== index}>
      {value === index && (
        <Box p={3} sx={{ minHeight: "70vh", p: 0 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
};

interface SubmitRequestModalProps {
  submitRequest: boolean;
  setSubmitRequest: () => void;
  selectedPoint: any;
}

const SubmitRequestModal: React.FC<SubmitRequestModalProps> = ({
  submitRequest,
  setSubmitRequest,
  selectedPoint,
}) => {
  const [value, setValue] = useState(0);
  const [editorContent, setEditorContent] = useState("");

  const handleEditorChange = (content: string) => {
    setEditorContent(content);
  };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    event.preventDefault();
    setValue(newValue);
  };
  const handleSubmit = () => {
    console.log("Form submitted!");
    setSubmitRequest();
  };

  return (
    <>
      <Modal open={submitRequest} onClose={setSubmitRequest}>
        <ModalBox>
          <Box
            sx={{
              background: "var(--darkgray)",
              color: "var(--white)",
              p: "5px 12px",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <Typography
              variant="h6"
              component="h6"
              sx={{
                fontSize: "16px",
                display: "flex",
                alignItems: "center",
                fontWeight: "bold",
              }}
            >
              Bericht aan de eigenaar (Message to Owner)
            </Typography>
            <IconButton onClick={setSubmitRequest}>
              <CloseIcon sx={{ color: "var(--white)" }} />
            </IconButton>
          </Box>

          {/* Content Wrapper */}
          <ContentWrapper>
            {/* Left Section */}
            <LeftSection>
              {/* Subject Radio Group */}
              <Typography
                sx={{
                  p: "8px 12px",
                  background: "var(--lightgray)",
                  fontWeight: "bold",
                  color: "var(--darkgray)",
                }}
              >
                Onderwerp
              </Typography>
              <RadioGroup defaultValue="toevoegen" sx={{ p: "8px 12px" }}>
                <FormControlLabel
                  value="toevoegen"
                  control={<Radio />}
                  label="Toevoegen"
                />
                <FormControlLabel
                  value="wijzigen"
                  control={<Radio />}
                  label="Wijzigen"
                />
                <FormControlLabel
                  value="verwijderen"
                  control={<Radio />}
                  label="Verwijderen"
                />
              </RadioGroup>

              {/* Text Area */}
              <Typography
                sx={{
                  p: "8px 12px",
                  background: "var(--lightgray)",
                  fontWeight: "bold",
                  color: "var(--darkgray)",
                }}
              >
                Bericht
              </Typography>
              <ReactQuill
                style={{ height: "200px", width: "100%", padding: "8px 10px" }}
                value={editorContent}
                onChange={handleEditorChange}
              />
              {/* Bottom Section */}
              <ButtonSection>
                <Button
                  onClick={handleSubmit}
                  variant="contained"
                  color="secondary"
                  sx={{
                    backgroundColor: "var(--red)",
                    textTransform: "none",
                  }}
                >
                  <Typography>Verzoek</Typography>
                </Button>
              </ButtonSection>
            </LeftSection>

            {/* Right Section */}
            <RightSection sx={{ borderRadius: "none" }}>
              <Box>
                {/* Tab headers */}
                <StyledTabs value={value} onChange={handleChange}>
                  <StyledTab label="Gegevens" />
                  <StyledTab label="Bijlagen" />
                </StyledTabs>

                {/* Tab Panels */}
                <TabPanel value={value} index={0}>
                  <SelectedPointDetail selectedPoint={selectedPoint} />
                </TabPanel>
                <TabPanel value={value} index={1}>
                  Content for Bijlagen (Attachments)
                </TabPanel>
              </Box>
            </RightSection>
          </ContentWrapper>
        </ModalBox>
      </Modal>
    </>
  );
};

export default SubmitRequestModal;
