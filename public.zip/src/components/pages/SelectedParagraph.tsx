import { Box, Button, Typography } from "@mui/material";
import EmailIcon from "@mui/icons-material/Email";
import { useState } from "react";
import SubmitRequestModal from "./SubmitRequestModal";
import SelectedPointDetail from "./SelectedPointDetail";

function SelectedParagraph({ selectedPoint }: { selectedPoint: string }) {
  const [submitRequest, setSubmitRequest] = useState(false);

  const handleRequest = () => {
    setSubmitRequest((prev) => !prev);
  };

  return (
    <Box
      sx={{
        backgroundColor: "var(--fade)",
        overflowY: "scroll",
        overflowX: "hidden",
      }}
    >
      {/* Button Section */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-start",
          width: "100%",
          p: "2px",
          background: "var(--darkgray)",
        }}
      >
        <Button
          onClick={handleRequest}
          variant="contained"
          color="secondary"
          sx={{
            backgroundColor: "var(--red)",
            textTransform: "none",
          }}
          startIcon={<EmailIcon />}
        >
          <Typography>Verzoek indienen</Typography>
        </Button>
      </Box>

      {/* Main Content */}
      <SelectedPointDetail selectedPoint={selectedPoint} />

      <SubmitRequestModal
        submitRequest={submitRequest}
        setSubmitRequest={handleRequest}
        selectedPoint={selectedPoint}
      />
    </Box>
  );
}

export default SelectedParagraph;
