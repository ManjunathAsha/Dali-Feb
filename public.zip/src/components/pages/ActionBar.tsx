import React from 'react';
import { Box, IconButton, Typography } from "@mui/material";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import SelectedChapters from "./SelectedChapters";
import SelectedParagraph from "./SelectedParagraph";

interface ActionBarProps {
  isOpen: boolean;
  toggleDrawer: () => void;
  actionBarType: 'selected-para' | 'selected-chapters';
  selectedPoint: any;
}

function ActionBar({ isOpen, toggleDrawer, actionBarType, selectedPoint }: ActionBarProps) {
  if (!isOpen) return null;

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', borderLeft: '1px solid rgba(0, 0, 0, 0.12)' }}>
      <Box sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        height: '48px',
        backgroundColor: '#C2185B',
        padding: '0 16px',
      }}>
        <IconButton
          onClick={toggleDrawer}
          sx={{
            color: "white",
            padding: "8px",
            '&:hover': {
              backgroundColor: "rgba(255, 255, 255, 0.08)",
            },
          }}
        >
          <ChevronRight />
        </IconButton>
        <Typography variant="h6" sx={{ color: 'white', marginLeft: 2 }}>
          {actionBarType === "selected-para" ? "Selected Paragraph" : "Selected Chapters"}
        </Typography>
      </Box>
      <Box sx={{ flexGrow: 1, overflowY: 'auto' }}>
        {actionBarType === "selected-para" ? (
          <SelectedParagraph selectedPoint={selectedPoint}/>
        ) : (
          <SelectedChapters />
        )}
      </Box>
    </Box>
  );
}

export default ActionBar;