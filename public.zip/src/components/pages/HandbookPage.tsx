import React, { useState } from "react";
import { Box, styled } from "@mui/material";
import PrimaryButton from "../utils/PrimaryButton";
import Expand from "@mui/icons-material/KeyboardDoubleArrowDown";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import VisibilityIcon from "@mui/icons-material/Visibility";
import Export from "@mui/icons-material/ExitToApp";
import Compress from "@mui/icons-material/KeyboardDoubleArrowUp";
import { chapters } from "../../components/utils/HandbookSections";
import HandbookDetails from "../../components/pages/HandbookDetails";
import ActionBar from "../../components/pages/ActionBar";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";

const StyledIconButton = styled("button")({
  borderRadius: "0px",
  color: "var(--white)",
  background: "var(--red)",
  minWidth: "10px",
  padding: "8px",
  border: "none",
  cursor: "pointer",
});

function Handbook() {
  const [expandedAll, setExpandedAll] = useState(false);
  const [expandedIds, setExpandedIds] = useState<string[]>([]);
  const [isDefaultView, setDefaultView] = useState(true);
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);
  const [actionBarType, setActionBarType] = useState<'selected-para' | 'selected-chapters'>("selected-chapters");
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (panelId: string) => {
    setExpandedIds((prev) =>
      prev.includes(panelId)
        ? prev.filter((id) => id !== panelId)
        : [...prev, panelId]
    );
  };

  const toggleExpandAll = () => {
    if (expandedAll) {
      setExpandedIds([]);
    } else {
      const allIds = chapters.flatMap((chapter: any) => [
        `chapter-${chapter.id}`,
        ...(chapter.level?.flatMap((level: any) => [
          `chapter-${chapter.id}-level-${level.id}`,
          ...(level.areas?.flatMap((area: any) => [
            `chapter-${chapter.id}-level-${level.id}-area-${area.id}`,
            ...(area.subject?.map(
              (subject: any) =>
                `chapter-${chapter.id}-level-${level.id}-area-${area.id}-subject-${subject.id}`
            ) || []),
          ]) || []),
        ]) || []),
      ]);
      setExpandedIds(allIds);
    }
    setExpandedAll(!expandedAll);
  };

  const toggleView = () => {
    setDefaultView((prev) => !prev);
  };

  const toggleDrawer = () => {
    setIsOpen(!isOpen);
  };

  const handleSelect = (point: any) => {
    if (!isOpen) {
      setIsOpen(true);
    }
    setActionBarType("selected-para");
    setSelectedPoint(point);
  };

  const handleShowSelected = () => {
    if (!isOpen) {
      setIsOpen(true);
    }
    setActionBarType("selected-chapters");
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>
    <Box sx={{ padding: 2, borderBottom: '1px solid rgba(0, 0, 0, 0.12)' }}>
      <Box sx={{ display: "flex", gap: 1 }}>
        <PrimaryButton
          label={expandedAll ? "Inklappen" : "Uitklappen"}
          icon={expandedAll ? <Compress /> : <Expand />}
          onClick={toggleExpandAll}
        />
        <PrimaryButton
          label="Selectie weergeven"
          icon={<CheckBoxIcon />}
          onClick={handleShowSelected}
        />
        <PrimaryButton
          label="Weergave veranderen"
          icon={<VisibilityIcon />}
          onClick={toggleView}
        />
        <PrimaryButton label="Resultaten exporteren" icon={<Export />} />
      </Box>
    </Box>
    
    <Box sx={{ display: "flex", flexGrow: 1, overflow: "hidden" }}>
      <Box
        sx={{
          flexGrow: 1,
          overflowY: "auto",
          transition: "width 0.3s ease",
          width: isOpen ? "calc(100% - 400px)" : "100%",
        }}
      >
        <HandbookDetails
          expandedAll={expandedAll}
          expandedIds={expandedIds}
          handleChange={handleChange}
          isDefaultView={isDefaultView}
          selectedPoint={selectedPoint}
          handleSelect={handleSelect}
        />
      </Box>

      <Box
        sx={{
          width: isOpen ? "400px" : "0px",
          transition: "width 0.3s ease",
          overflow: "hidden",
        }}
      >
        <ActionBar
          isOpen={isOpen}
          toggleDrawer={toggleDrawer}
          actionBarType={actionBarType}
          selectedPoint={selectedPoint}
        />
      </Box>
    </Box>
  </Box>
  );
}

export default Handbook;
