import React from "react";
import { Box, IconButton, Tooltip, Typography } from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";

const sectionTitleStyles = {
  fontWeight: "bold",
  p: 1,
  color: "var(--darkgray)",
  background: "var(--lightgray)",
};

const sectionContentStyles = {
  p: 1,
};

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <Box>
      <Typography variant="subtitle2" sx={sectionTitleStyles}>
        {title}
      </Typography>
      {children}
    </Box>
  );
}

function SelectedPointDetail({ selectedPoint }:any) {
  return (
    <Box>
      {/* Owner Section */}
      <Section title="Eigenaar">
        <Typography sx={sectionContentStyles}>Saanvi Owner</Typography>
      </Section>

      {/* Selected Requirement Section */}
      <Section title="Geselecteerde eis">
        <Typography sx={sectionContentStyles}>{selectedPoint}</Typography>
      </Section>

      {/* Attachments Section */}
      <Section title="Bijlagen">
        <Typography sx={sectionContentStyles}>
          Momenteel zijn er geen bijlagen gekoppeld
        </Typography>
      </Section>

      {/* References Section */}
      <Section title="Bronverwijzingen">
        <Typography sx={sectionContentStyles}>
          Momenteel zijn er geen bronverwijzingen gekoppeld
        </Typography>
      </Section>

      {/* Hardness Section */}
      <Section title="Hardheid">
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            pb: 2,
          }}
        >
          <Typography sx={sectionContentStyles}>Richtlijn (R)</Typography>
          <Tooltip title="Hardheid informatie" arrow>
            <IconButton>
              <InfoIcon />
            </IconButton>
          </Tooltip>
        </Box>
      </Section>
    </Box>
  );
}

export default SelectedPointDetail;
