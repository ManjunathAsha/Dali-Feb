import React from "react";
import { Button } from "@mui/material";
import { useTheme, useMediaQuery } from "@mui/material";

interface IconLabel {
  icon?: React.ReactNode;
  label: string;
  onClick?: any;
}

function PrimaryButton({ icon, label, onClick }: IconLabel) {
  const theme = useTheme();
  const isMediumScreen = useMediaQuery(theme.breakpoints.down(700)); // Adjust for screen size < 700px

  return (
    <Button
      type="button"
      variant="contained"
      size="small"
      onClick={onClick}
      sx={{
        backgroundColor: "transparent",
        color: "var(--black)",
        border: "1px solid var(--gray)",
        textTransform: "none",
        width: isMediumScreen ? '50%' : 'auto', // Half width on small screens, auto on large
        margin: '5px', // Uniform margin for alignment
        display: 'flex',
        justifyContent: 'center',
        "&:hover": {
          backgroundColor: "var(--red)",
          color: "var(--white)",
        },
      }}
      startIcon={icon}
    >
      {label}
    </Button>
  );
}

export default PrimaryButton;
